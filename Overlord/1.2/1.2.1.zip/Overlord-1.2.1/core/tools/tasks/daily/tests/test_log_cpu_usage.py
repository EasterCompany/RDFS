# Overlord library
from core.tools.tasks.daily import log_cpu_usage as sut


def test_log_cpu_usage_for_today():
  assert "Example unit test"
