#  api/apps.py
#    automatically generated file
#    do not modify or remove

# Overlord library
from core.library import AppConfig


class ApiConfig(AppConfig):
    name = 'api'
