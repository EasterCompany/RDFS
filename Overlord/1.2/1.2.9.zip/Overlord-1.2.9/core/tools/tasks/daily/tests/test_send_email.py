
def test_send_email():
  assert True
