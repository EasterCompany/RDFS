#  core/models.py
#    automatically generated file
#    do not modify or remove

# Overlord Core Models
from core.model.user.tables import *
from core.model.jobs.tables import *
from core.model.posts.tables import *
from core.model.recipe.tables import *
