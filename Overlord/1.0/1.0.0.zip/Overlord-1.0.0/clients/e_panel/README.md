
<div style="margin:0 0 128px 0;">
  <p align="center" style="border-bottom:0px;padding:9px 0 0 0;"> [OVERLORD] </p>
  <h1 align="center" style="margin-bottom:64px;border-bottom:0px;"> Admin Panel </h1>
  <div style="display:flex;flex-direction:column;max-width:90%;width:680px;margin:0 auto;font-size:small;">
    <h4 align="center" style="border-bottom:1px solid lightgrey;margin:0;padding-top:8px;"> ⋄ GIT ⋄ </h4>
    <p align="left" style="padding:9px;">
      <b>DIRECTORY</b>:
        /Master/Int/Dev/clients/admin
      <br/>
      <b>REPOSITORY</b>:
        <a href="https://github.com/EasterCompany/Overlord-Admin">
          Admin (Dev)
        </a>
      <br/>
      <b>CLONE</b>:
        <code style='background-color:lightgrey;padding:2px;border-radius:2px;color:black;'>
          -b dev git@github.com:EasterCompany/Overlord-Admin.git admin
        </code>
      <br/>
    </p>
    <h4 align="center" style="border-bottom:1px solid lightgrey;margin:0;"> ⋄ PRODUCTION ⋄ </h4>
    <p align="left" style="padding:9px;">
      <b>DIRECTORY</b>:
        /Master/Int/Staging/clients/admin
      <br/>
      <b>HTTPS</b>:
        <a href="https://eastercompany.eu.pythonanywhere.com/">
          eastercompany.eu.pythonanywhere.com
        </a>
      <br/>
      <b>CLONE</b>:
        <code style='background-color:lightgrey;padding:2px;border-radius:2px;color:black;'>
          -b main git@github.com:EasterCompany/Overlord-Admin.git admin
        </code>
      <br/>
    </p>
  </div>
</div>
